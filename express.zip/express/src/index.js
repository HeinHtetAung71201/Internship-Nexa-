const express = require('express')
const app = express()
const port = 3000

app.use(express.json()) //body parser

app.get('/test', (req, res) => {
  res.json({
    message: "hello world"
  })
})

app.get('/user', (req, res) => {
    const users = [{name: "user1"}, {name: "user 2"}]
    console.log("get usr list")
  res.json({
    message: "get user list",
    data: users
  })
})

app.post('/user/:id', (req, res) => {
    console.log(req.body, "body") 
    const token = req.headers.token
    const id = req.params.id
    const { name } = req.body // { name: 'Hein Htet Aung' }
    console.log("create user")
  res.json({
    message: "create user",
    data: name,
    token,
    id
  })
})

app.put('/user/:id', (req, res) => {
    console.log(req.body, "body") 
    const token = req.headers.token
    const id = req.params.id
    const { name } = req.body // { name: 'Hein Htet Aung' }
    console.log("create user")
  res.json({
    message: "create user",
    data: name,
    token,
    id
  })
})

app.listen(port, () => {
  console.log(`Example app listening on port http://localhost:${port}`)
})